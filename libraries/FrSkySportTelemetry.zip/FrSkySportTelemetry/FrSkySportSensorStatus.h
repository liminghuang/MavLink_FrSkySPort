/*
  FrSky STATUS sensor class for Teensy 3.x and 328P based boards (e.g. Pro Mini, Nano, Uno)
  (C) 2015 Clooney
  Not for commercial use
*/

#ifndef _FRSKY_SPORT_SENSOR_STATUS_H_
#define _FRSKY_SPORT_SENSOR_STATUS_H_

#include "FrSkySportSensor.h"

#define STATUS_DEFAULT_ID ID19
#define STATUS_DATA_COUNT 1
#define STATUS_DATA_ID 0x0600
#define STATUS_DATA_PERIOD 500

#define TELEM_TEXT_MESSAGE_MAX  128
#define TELEM_NUM_BUFFERS         8

class FrSkySportSensorStatus : public FrSkySportSensor
{
  public:
    FrSkySportSensorStatus(SensorId id = STATUS_DEFAULT_ID);
    //void setData(float status);
    void setDebug(bool debug);
    void send_text_message(char *msg);
    void load_next_buffer();
    char get_next_message_byte();
    uint16_t text_get_word();
    void console_print(const char* fmt, ...);
    void debug_print(const char* fmt, ...);
    virtual void send(FrSkySportSingleWireSerial& serial, uint8_t id, uint32_t now);

  private:
    uint16_t status; // data_word
    uint32_t statusTime;

    char msg[TELEM_TEXT_MESSAGE_MAX];
    char text_message_data_buffer[TELEM_NUM_BUFFERS][TELEM_TEXT_MESSAGE_MAX];
    uint8_t text_message_index = 0;
    uint32_t message_expiry = 0L;
    uint16_t message_packet_sequence = 0;
    uint16_t current_message_number = 0;
    uint16_t next_message_number = 1;

    bool _debug;
};

#endif // _FRSKY_SPORT_SENSOR_STATUS_H_
