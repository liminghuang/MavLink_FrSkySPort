/*
  FrSky STATUS sensor class for Teensy 3.x and 328P based boards (e.g. Pro Mini, Nano, Uno)
  (C) 2015 Clooney
  Not for commercial use
*/

#include "FrSkySportSensorStatus.h"

FrSkySportSensorStatus::FrSkySportSensorStatus(SensorId id) : FrSkySportSensor(id) { }
/*
void FrSkySportSensorStatus::setData(float status)
{
  FrSkySportSensorStatus::status = (uint32_t)(status);
}
*/
void FrSkySportSensorStatus::send(FrSkySportSingleWireSerial& serial, uint8_t id, uint32_t now)
{
  if(sensorId == id)
  {
    if(now > statusTime)
    {
      statusTime = now + STATUS_DATA_PERIOD;
      status = FrSkySportSensorStatus::text_get_word();
      if(_debug == true) {
        debug_print("FRSKY SENSOR_ID_RPM: %d", status);
      }
      serial.sendData(STATUS_DATA_ID, status);
    }
    else
    {
      serial.sendEmpty(STATUS_DATA_ID);
    }
  }
}

void FrSkySportSensorStatus::setDebug(bool debug)
{
  _debug = debug;
}

void FrSkySportSensorStatus::send_text_message(char *msg) {
  uint8_t c;
  uint16_t dst_index = 0;
  for (uint i = 0; i < strlen(msg); i++) {
    c = msg[i];
    if (c >= 32 && c <= 126) {
      text_message_data_buffer[next_message_number % TELEM_NUM_BUFFERS][dst_index++] = c;
    }
  }
  text_message_data_buffer[next_message_number % TELEM_NUM_BUFFERS][dst_index++] = 0;
  next_message_number++;
}

void FrSkySportSensorStatus::load_next_buffer() {
  if (millis() > message_expiry) {
    if ((current_message_number + 1) < next_message_number) {
      message_expiry = millis() + 2000;
      current_message_number++;
    } else {
      text_message_data_buffer[current_message_number % TELEM_NUM_BUFFERS][0] = '\0';
      message_expiry = millis();                                                              // No reason to keep blank up for a set time
    }
  }
  text_message_index = 0;
}

char FrSkySportSensorStatus::get_next_message_byte() {
  if (current_message_number == next_message_number) {
    return '\0';
  } else if (text_message_index >= strlen(text_message_data_buffer[current_message_number % TELEM_NUM_BUFFERS])) {
    return '\0';
  } else {
    return text_message_data_buffer[current_message_number % TELEM_NUM_BUFFERS][text_message_index++] & 0x7f;
  }
}

uint16_t FrSkySportSensorStatus::text_get_word() {                                                      // LSB is lost so use upper 15 bits
  uint16_t data_word;
  char ch, cl;
  ch = get_next_message_byte();
  data_word = ch << 8;
  cl = get_next_message_byte();
  data_word |= cl << 1;
  data_word |= (message_packet_sequence++ & 1) << 15;                                // MSB will change on each telemetry packet so rx knows to update message
  if (ch == '\0' || cl == '\0') {
    load_next_buffer();
  }
  return data_word;
}

void FrSkySportSensorStatus::console_print(const char* fmt, ...) {
  char formatted_string[256];
  va_list argptr;
  va_start(argptr, fmt);
  vsprintf(formatted_string, fmt, argptr);
  va_end(argptr);
  Serial.print(formatted_string);
}

void FrSkySportSensorStatus::debug_print(const char* fmt, ...) {
  char formatted_string[256];
  va_list argptr;
  va_start(argptr, fmt);
  vsprintf(formatted_string, fmt, argptr);
  va_end(argptr);
  console_print("%d \t%s\r\n", millis(), formatted_string);
}
